export PORT=8080
uwsgi uwsgi.ini